import React from 'react';
import Login from './Login';
import './mainpage.css'

const mainpage=()=>{

    return(
        <div className='viewpage'>
            <Login />
            
        </div>
    );
}
export default mainpage;